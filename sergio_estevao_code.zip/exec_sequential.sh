#!/bin/bash

echo "-> basic"
./bin/basic.out
echo "-> multiples"
./bin/multiples.out
echo "-> segmented"
./bin/segmented.out