## Speedup

- SPMD

6 proc - 7.9797/1.50547 = 5.3 <br/>
12 proc - 7.9797/1.42349 = **5.6**

- Threaded without SPMD

6 proc - 8.04075/1.50547 = 5.2 <br/>
12 proc - 8.04075/1.42349 = 5.486