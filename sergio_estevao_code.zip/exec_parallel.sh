#!/bin/bash

echo "-> spmd"
./bin/spmd.out
echo "-> parallel"
./bin/parallel.out
echo "-> tasks"
./bin/tasks.out